package com.cg.capstore.bean;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name= "mycartproduct")
public class CartProduct {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int CartProductId;
	private long productId;
	private int Quantity;
	@ManyToOne
	private MyCart mycart;
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public CartProduct(long productId, int quantity) {
		super();
		this.productId = productId;
		Quantity = quantity;
	}
	public CartProduct() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CartProduct [productId=" + productId + ", Quantity=" + Quantity + "]";
	}
	public CartProduct(int cartProductId, long productId, int quantity, MyCart mycart) {
		super();
		CartProductId = cartProductId;
		this.productId = productId;
		Quantity = quantity;
		this.mycart = mycart;
	}
	
	

}
