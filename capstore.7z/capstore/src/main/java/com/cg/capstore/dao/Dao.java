package com.cg.capstore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Admin;
import com.cg.capstore.bean.CartProduct;
import com.cg.capstore.bean.Coupon;
import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Feedback;
import com.cg.capstore.bean.Image;
import com.cg.capstore.bean.Invoice;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.bean.MyAddress;
import com.cg.capstore.bean.MyCart;
import com.cg.capstore.bean.MyOrders;
import com.cg.capstore.bean.MyWishList;
import com.cg.capstore.bean.Product;
import com.cg.capstore.bean.SavedCardDetails;

@Repository
@Transactional
public class Dao
{
	@PersistenceContext
	EntityManager em;
	

	MyAddress myaddress = new MyAddress();
	
	Admin admin= new Admin();

	Coupon coupon= new Coupon();

	Customer customer= new Customer();

	Feedback feedback = new Feedback();
	 

	Image image=new Image();
	
	Invoice invoice= new Invoice();

	Merchant merchant= new Merchant();
	
	MyCart cart= new MyCart();

	MyOrders orders= new MyOrders();

	MyWishList wishlist= new MyWishList();

	Product product= new Product();
	
	CartProduct cartprod = new CartProduct();

	SavedCardDetails cardDetails = new SavedCardDetails();

	 public void manage()
	 {
		em.persist(admin);
		em.persist(coupon);
		em.persist(myaddress);
		em.persist(image);
		em.persist(invoice);
		em.persist(feedback);
		em.persist(product);
		em.persist(wishlist);
		em.persist(cart);
		em.persist(orders);
		em.persist(customer);
		em.persist(cardDetails);
		em.persist(merchant);
		em.persist(cartprod);
	 }
}
