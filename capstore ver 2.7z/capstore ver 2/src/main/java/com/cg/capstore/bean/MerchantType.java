package com.cg.capstore.bean;

public enum MerchantType
{
	NORMAL,THIRD_PARTY;
}
