package com.cg.capstore.dao;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Customer;
@Transactional
public interface capstoreDao5  extends JpaRepository<Customer, String> {

}
